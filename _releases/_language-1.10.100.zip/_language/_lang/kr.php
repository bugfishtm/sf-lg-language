<?php if(isset($this)) { if(!is_object($this)) { Header("Location: ../"); exit(); } } else { Header("Location: ../"); exit(); }
#	 ____  _   _ ___ _____ _____ _____ ___ ____  _   _ 
#	/ ___|| | | |_ _|_   _| ____|  ___|_ _/ ___|| | | |
#	\___ \| | | || |  | | |  _| | |_   | |\___ \| |_| |
#	 ___) | |_| || |  | | | |___|  _|  | | ___) |  _  |
#	|____/ \___/|___| |_| |_____|_|   |___|____/|_| |_|                       
#									  __       _  _  _  _ __    __ 
#									 / /(\/\/)( \( \( \( \\ \  / / 
#									( (  )  (  ) )) )) )) )) )( (  
#									 \_\(/\/\)(_/(_/(_/(_//_/  \_\ 
#
#	Copyright (C) 2026 Jan Maurice Dahlmanns [Bugfish]
#	This file is part of the core library and is NOT included
#	in any sublicense or third-party license agreements.
#
#	This program is free software: you can redistribute it and/or modify
#	it under the terms of the GNU General Public License as published by
#	the Free Software Foundation, either version 3 of the License, or
#	(at your option) any later version.
#
#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU General Public License for more details.
#
#	You should have received a copy of the GNU General Public License
#	along with this program.  If not, see <https://www.gnu.org/licenses/>. ?>
store_version_name=템플릿: 언어 모듈  
store_version_description=Suitefish 관리자 모듈 내에서 구현하도록 설계된 언어 통합 모듈의 예시입니다.  
